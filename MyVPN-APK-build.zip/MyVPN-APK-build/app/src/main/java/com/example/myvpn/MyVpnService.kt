package com.example.myvpn

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor

class MyVpnService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null

    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int
    ): Int {
        establishLocalTunnel()
        return START_STICKY
    }

    private fun establishLocalTunnel() {
        vpnInterface?.close()

        vpnInterface = Builder()
            .setSession("My VPN")
            .setMtu(1500)
            .addAddress("10.8.0.2", 24)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("1.1.1.1")
            .establish()
    }

    override fun onDestroy() {
        vpnInterface?.close()
        vpnInterface = null
        super.onDestroy()
    }

    override fun onRevoke() {
        vpnInterface?.close()
        vpnInterface = null
        stopSelf()
        super.onRevoke()
    }
}
