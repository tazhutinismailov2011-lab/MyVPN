# MyVPN — Android Studio / GitHub Actions

Готовый исходный проект Android-приложения VPN на Kotlin + Jetpack Compose.

## Что есть

- Android application project
- Kotlin + Jetpack Compose
- Android `VpnService`
- экран подключения/отключения
- GitHub Actions для автоматической сборки APK
- debug APK как artifact

## Сборка только с телефона

Подробная инструкция находится в `BUILD_ON_PHONE.md`.

Кратко:

1. Создайте GitHub-репозиторий.
2. Загрузите содержимое этого проекта.
3. Откройте GitHub → Actions.
4. Запустите `Build APK`.
5. После завершения скачайте artifact `MyVPN-debug-apk`.
6. Внутри будет `app-debug.apk`.

## Важно про VPN

Текущий проект демонстрирует Android `VpnService` и создаёт локальный VPN-интерфейс.

Это НЕ полноценный удалённый VPN-сервис: для маршрутизации трафика через интернет-сервер нужно добавить реальный VPN-протокол, например WireGuard, и серверную конфигурацию.
