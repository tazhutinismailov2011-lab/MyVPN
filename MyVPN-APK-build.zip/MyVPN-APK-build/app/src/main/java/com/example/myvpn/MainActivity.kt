package com.example.myvpn

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {

    private var vpnAllowed by mutableStateOf(false)
    private var connected by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    VpnScreen(
                        connected = connected,
                        onToggle = { toggleVpn() }
                    )
                }
            }
        }
    }

    private fun toggleVpn() {
        if (connected) {
            stopService(Intent(this, MyVpnService::class.java))
            connected = false
            return
        }

        val prepareIntent = VpnService.prepare(this)

        if (prepareIntent != null) {
            startActivityForResult(prepareIntent, REQUEST_VPN_PERMISSION)
        } else {
            startVpn()
        }
    }

    private fun startVpn() {
        startService(Intent(this, MyVpnService::class.java))
        connected = true
    }

    @Deprecated("Activity Result API can replace this in a future revision.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == REQUEST_VPN_PERMISSION && resultCode == Activity.RESULT_OK) {
            startVpn()
        }
    }

    companion object {
        private const val REQUEST_VPN_PERMISSION = 1001
    }
}

@Composable
private fun VpnScreen(
    connected: Boolean,
    onToggle: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "My VPN",
            style = MaterialTheme.typography.headlineLarge
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = if (connected) "VPN подключён" else "VPN отключён",
            style = MaterialTheme.typography.titleMedium
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(onClick = onToggle) {
            Text(if (connected) "Отключить" else "Подключить")
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "Демо-режим: приложение использует Android VpnService. " +
                    "Для настоящего удалённого VPN нужен сервер и реализация VPN-протокола.",
            style = MaterialTheme.typography.bodyMedium
        )
    }
}
